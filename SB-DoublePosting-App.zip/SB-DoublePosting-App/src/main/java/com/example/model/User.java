package com.example.model;

public class User {

	public String uname;
	public String email;
	public String phno;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}

	@Override
	public String toString() {
		return "User [uname=" + uname + ", email=" + email + ", phno=" + phno + "]";
	}

}
