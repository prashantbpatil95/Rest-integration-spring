package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.model.User;

@Controller
public class UserController {

	@RequestMapping(value = { "/", "/createUser" }, method = RequestMethod.GET)
	public String loadForm(Model model) {
		model.addAttribute("user", new User());
		return "createUser";
	}

	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	public String submitForm(@ModelAttribute("user") User user, RedirectAttributes redirectAttr) {
		System.out.println("User :: " + user);
		redirectAttr.addFlashAttribute("msg", "Success");
		return "redirect:/regSuccess";
	}

	@RequestMapping(value = "/regSuccess")
	public String regSuccess(@ModelAttribute("user") User user, Model model) {
		System.out.println("**Reg Success**");
		return "createUser";
	}
}
